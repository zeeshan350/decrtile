# Login-Register-using-php-MySQL-in-ionic
A tutorial on how to setup  login and register in ionic3 using PHP and MySQL
